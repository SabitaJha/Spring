# Springboot-Angular-WebAPI
A Web API that performs Crud operations on MySQL server. 
